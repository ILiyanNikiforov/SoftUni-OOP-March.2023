from project.animal import Animal


class Dog(Animal):
    def bark(self):
        return "barking..."

#
# my_dog = Dog()
# print(my_dog.eat())
# print(my_dog.bark())
