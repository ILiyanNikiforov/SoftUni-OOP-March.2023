from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    pass

#
# hero = Hero("H", 4)
# print(hero.username)
# print(hero.level)
# print(str(hero))

